module EvadeRacing {
    requires hanyaeger;

    exports com.github.hanyaeger.racing;

//    opens audio;
    opens backgrounds;
    opens sprites;
    opens Obstakels;
    opens PowerUp;
    opens PowerDowns;
}
